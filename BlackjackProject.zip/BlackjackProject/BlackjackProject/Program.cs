﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using Blackjack;

namespace Blackjack
{
    public class Program
    { 
        private static Deck deck = new Deck(); //Instantiate Deck
        private static Player player = new Player(); //Instantiate Player


        private enum Results //Hand Results
        {
            PUSH,
            WinPlayer,
            BustPlayer,
            BlackjackPlayer,
            WinDealer,
            GiveUp,
            NoBet
        }

        static void InitializeHands() //Hand Initialization
        {
            deck.Initialize();

            player.Hand = deck.DealHand();
            Dealer.HiddenCards = deck.DealHand();
            Dealer.RevealedCards = new List<Card>();

            // If hand contains two aces, make one Hard.
            if (player.Hand[0].Face == Face.Ace && player.Hand[1].Face == Face.Ace) //Hard ace is a 1, Soft ace is an 11. On two soft aces, that would be 22 which is 
                                                                                    //An auto-bust.
            {
                player.Hand[1].Value = 1;
            }

            if (Dealer.HiddenCards[0].Face == Face.Ace && Dealer.HiddenCards[1].Face == Face.Ace) //Same thing for the dealer.
            {
                Dealer.HiddenCards[1].Value = 1;
            }

            Dealer.RevealCard();

            player.WriteHand();
            Dealer.WriteHand();
        }

        static void StartRound() //Start Round clears the console, takes bet, starts the hand, takes actions, reveals cards in hand and one card of the dealer
                                 
        {
            Console.Clear();

            if (!TakeBet())
            {
                EndRound(Results.NoBet);
                return;
            }
            Console.Clear();

            InitializeHands();
            TakeActions();

            Dealer.RevealCard();

            Console.Clear();
            player.WriteHand();
            Dealer.WriteHand();

            player.HandsCompleted++;

            if (player.Hand.Count == 0)
            {
                EndRound(Results.GiveUp);
                return;
            }
            else if (player.GetHandValue() > 21)
            {
                EndRound(Results.BustPlayer); //Player is busted if hand value is higher than 21.
                return;
            }

            while (Dealer.GetHandValue() <= 16) //While hand value of dealer is less or equal to 16, it will continue to draw cards.
            {
                Thread.Sleep(1000);
                Dealer.RevealedCards.Add(deck.DrawCard());

                Console.Clear();
                player.WriteHand();
                Dealer.WriteHand();
            }


            if (player.GetHandValue() > Dealer.GetHandValue()) //If player hand value is higher than dealer hand value, player wins
            {
                player.Wins++;
                if (Casino.IsHandBlackjack(player.Hand)) //If the hand is a blackjack, do a special win
                {
                    EndRound(Results.BlackjackPlayer);
                }
                else
                {
                    EndRound(Results.WinPlayer); //If hand is not blackjack, do normal win
                }
            }
            else if (Dealer.GetHandValue() > 21) //If dealer busts, player wins
            {
                player.Wins++;
                EndRound(Results.WinPlayer);
            }
            else if (Dealer.GetHandValue() > player.GetHandValue()) //If dealer hand is higher, dealer wins
            {
                EndRound(Results.WinDealer);
            }
            else
            {
                EndRound(Results.PUSH); //push to next hand
            }

        }


        static void TakeActions()
        {
            string action;
            do
            {
                Console.Clear();
                player.WriteHand();
                Dealer.WriteHand();

                Console.Write("Enter Action (? for help): ");
                Console.ForegroundColor = ConsoleColor.Cyan;
                action = Console.ReadLine();
                Casino.ResetColor();

                switch (action.ToUpper())
                {
                    case "HIT":
                        player.Hand.Add(deck.DrawCard());
                        break;
                    case "STAND":
                        break;
                    case "SURRENDER":
                        player.Hand.Clear();
                        break;
                    case "DOUBLE": //double down adds twice bet
                        if (player.Chips <= player.Bet)
                        {
                            player.AddBet(player.Chips);
                        }
                        else
                        {
                            player.AddBet(player.Bet);
                        }
                        player.Hand.Add(deck.DrawCard());
                        break;
                    default: //Help menu
                        Console.WriteLine("Valid Moves:");
                        Console.WriteLine("Hit, Stand, Surrender, Double");
                        Console.WriteLine("Press any key to continue.");
                        Console.ReadKey();
                        break;
                }

                if (player.GetHandValue() > 21) //if the hand value is higher than 21 and there is an ace, casino rules say that ace becomes hard and its value is 1
                {
                    foreach (Card card in player.Hand)
                    {
                        if (card.Value == 11)
                        {
                            card.Value = 1;
                            break;
                        }
                    }
                }
            } while (!action.ToUpper().Equals("STAND") && !action.ToUpper().Equals("DOUBLE")
                && !action.ToUpper().Equals("SURRENDER") && player.GetHandValue() <= 21); //Present menu while the user does not select a valid command.
        }

 
        static bool TakeBet() //Take bet class
        {
            Console.Write("Current Chip Count: ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(player.Chips); //present chip count
            Casino.ResetColor();

            Console.Write("Minimum Bet: "); //present minimum bet amount (10)
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(Casino.MinimumBet);
            Casino.ResetColor();

            Console.Write("Enter bet to begin hand " + player.HandsCompleted + ": "); //Request input for bet
            Console.ForegroundColor = ConsoleColor.Magenta;
            string s = Console.ReadLine();
            Casino.ResetColor();

            if (Int32.TryParse(s, out int bet) && bet >= Casino.MinimumBet && player.Chips >= bet)
            {
                player.AddBet(bet); //Set bet value to indicated value
                return true;
            }
            return false;
        }

        static void EndRound(Results result) //Class endround
        {
            switch (result)
            {
                case Results.PUSH: //If PUSH at end of round
                    player.ReturnBet();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("Player and Dealer Push.");
                    break;
                case Results.WinPlayer: //if player wins
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Player Wins " + player.WinBet(false) + " chips");
                    Console.Beep(220, 250); //neat tune to indicate win
                    Console.Beep(523, 750);
                    Console.Beep(600, 250);

                    break;
                case Results.BustPlayer: //if player busts
                    player.ClearBet();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Player Busts");
                    Console.Beep(600, 250); //Tone to indicate bust
                    Console.Beep(220, 750);
                    break;
                case Results.BlackjackPlayer: //If player gets blackjack
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Player Wins " + player.WinBet(true) + " chips with Blackjack.");
                    Console.Beep(220, 250); //Tone to indicate blackjack
                    Console.Beep(523, 750);
                    Console.Beep(600, 250);

                    break;
                case Results.WinDealer: //Dealer wins
                    player.ClearBet();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Beep(600, 250); //Tone to indicate dealer wins
                    Console.Beep(600, 250);
                    Console.Beep(220, 250);


                    Console.WriteLine("Dealer Wins.");
                    break;
                case Results.GiveUp: //Surrender
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("By surrendering, you lose " + (player.Bet / 2) + " chips");
                    player.Chips += player.Bet / 2;
                    player.ClearBet();
                    break;
                case Results.NoBet: //Invalid bet
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid Bet.");
                    break;
            }

            if (player.Chips <= 0) //If player runs out of chips
            {
                Console.ForegroundColor = ConsoleColor.Red;

                Console.WriteLine();
                Console.WriteLine("You ran out of Chips after " + (player.HandsCompleted - 1) + " rounds.");
                Console.WriteLine("500 Chips will be added and your statistics have been reset.");

                player = new Player();
            }

            Casino.ResetColor();
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
            StartRound();
        }

        static void Main(string[] args)
        {
         
            Console.OutputEncoding = Encoding.UTF8;

            Casino.ResetColor(); //main menu
            Console.Title = "Blackjack";

            Console.WriteLine("Welcome to Blackjack!");
            Console.WriteLine("Press any key to play.");
            Console.ReadKey();
            StartRound();
        }
    }
}
