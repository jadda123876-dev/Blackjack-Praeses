﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using static Blackjack.Suit;
using static Blackjack.Face;

namespace Blackjack
{
    public enum Suit //Suit Class
    {
        Clubs,
        Spades,
        Diamonds,
        Hearts
    }
    public enum Face //Face class
    {
        Ace,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King
    }

    public class Card //Card Class
    {
        public Suit Suit { get; }
        public Face Face { get; }
        public int Value { get; set; }
        public char Symbol { get; }

        public Card(Suit suit, Face face)
        {
            Suit = suit;
            Face = face;

            switch (Suit) //When a certain suit is determined
            {
                case Clubs: //Make card clubs
                    Symbol = '♣';
                    break;
                case Spades: //Make card spades
                    Symbol = '♠';
                    break;
                case Diamonds: //Make card diamonds
                    Symbol = '♦';
                    break;
                case Hearts: //Make card hearts
                    Symbol = '♥';
                    break;
            }
            switch (Face) //When a certain face is determined
            {
                case Ten:
                case Jack:
                case Queen:
                case King: //Case face cards
                    Value = 10;
                    break;
                case Ace: //Case Ace (Soft ace is determined separately)
                    Value = 11;
                    break;
                default:
                    Value = (int)Face + 1;
                    break;
            }
        }

        public void WriteDescription()
        {
            if (Suit == Suit.Diamonds || Suit == Suit.Hearts) //if suit is diamonds or hearts, make color red
            {
                Console.ForegroundColor = ConsoleColor.Red;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White; //Using white for black suits since black on black console would look weird
            }

            if (Face == Ace) //If ace
            {
                if (Value == 11)
                {
                    Console.WriteLine(Symbol + " Soft " + Face + " of " + Suit);
                }
                else
                {
                    Console.WriteLine(Symbol + " Hard " + Face + " of " + Suit);
                }
            }
            else
            {
                Console.WriteLine(Symbol + " " + Face + " of " + Suit);
            }
            Casino.ResetColor();
        }
    }
}